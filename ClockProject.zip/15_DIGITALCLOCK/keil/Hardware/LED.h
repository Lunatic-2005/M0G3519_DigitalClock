#ifndef __LED_H
#define __LED_H

void LED_allOn();
void LED_On(int num);
void LED_Off(int num);
void LED_allOff();

#endif